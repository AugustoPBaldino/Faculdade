#include <stdio.h>
#include <pthread.h>
#include <unistd.h>
#include <stdbool.h>
#include <stdlib.h>
#include <semaphore.h>

#define MAX_RESOURCES 1000
#define MAX_READERS 1000

bool want[MAX_READERS]; // Vetor de intenções
int turn; // Variável de controle de turno

long int max_r, r = 0, canibais; // "Maximo de porcoes", "Porcoes disponiveis", "Numero de canibais" (Threads) 
bool control_alim = false;  //true == cozinheiro a cozinhar/canibais a esperar, 
                            //false == cozinheiro a dormir/canibais podem comer

//------------------------------------------------------
// Definição das funções do Canibais e do Cozinheiro
void *mesa(void *arg)
{
    long int i;
    i = (long int)arg;
    while (1) {
        usleep(1000);
        if (control_alim == false) {
            want[i] = true; // Sinaliza a intenção de entrar na seção crítica
            turn = i; // Define o turno para o processo atual
            bool other_wants = false; // Verifica se o outro processo quer entrar
            for (int j = 0; j < MAX_READERS; j++) {
                if (j != i && want[j]) {
                    other_wants = true;
                    break;
                }
            }
            printf("Canibal %ld está %d, mas ficou %d por %d\n",i,other_wants,want[i],want[1 - i]);
            turn = 1 - i; // Passa o turno para o outro processo
            printf("%d e %d ",turn,other_wants);
            while (other_wants && turn == 1 - i) {} // Espera até que seja sua vez e o outro não queira mais entrar
            if (r > 0) {
                r--;

                printf(" Canibal %3ld pegou %3ld porcao e foi embora\n\n", i,r + 1);
                if (r == 0) { // Quando não há mais porções com comida, o último canibal acorda o cozinheiro
                    control_alim = true;
                }
                 usleep(10000 * canibais);

            }
            want[i] = false; // Sinaliza que não deseja mais entrar na seção crítica
            //printf("Canibal %ld saiu com %d\n",i,want[i]);

        }
    }
}


void *cozinha(void *arg) {//Enquanto houver porcoes disponiveis, o cozinheiro está dormindo
    while (1) {
        while (control_alim == false) {
            usleep(100000);//Cozinheiro está a dormir
        }
        usleep(100000);
        //acorda o cozinheiro
        printf("\n O cozinheiro acordou\n");
        usleep(100000);
        //enche a travessa
        r = max_r;
        printf(" Cozinheiro encheu a travessa\n");
        printf(" Cozinheiro voltou a dormir\n\n");
        control_alim = false;
    }
}

//------------------------------------------------------
// main fuctions
int main(int argc, char *argv[]) {
    if (argc < 3) {
        printf("Uso: %s <num_porcoes> <num_canibais> \n", argv[0]);
        return 1;
    }

    max_r = atoi(argv[1]);
    printf("Numero de porcoes: %ld\n", max_r);
    canibais = atoi(argv[2]);

    if (max_r > MAX_RESOURCES || canibais > MAX_READERS) {
        printf("Número máximo de porcoes ou canibais excedido.\n");
        return 1;
    }

    pthread_t threads[canibais + 1];// +1 == cozinheiro

    control_alim = true;
    // Iniciando o Cozinheiro
    pthread_create(&threads[canibais], NULL, cozinha, (void *)0);

    // Criando as threads dos canibais
    for (long int i = 0; i < canibais; i++) {
        pthread_create(&threads[i], NULL, mesa, (void *)i);
    }

    printf("\n");

    pthread_exit(NULL);

    return 0;
}
