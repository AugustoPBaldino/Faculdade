#include <stdio.h>
#include <pthread.h>
#include <unistd.h>
#include <stdlib.h>
#include <limits.h>
#include <semaphore.h>

#define BUFFER_SIZE 5
#define MAX_ITEMS 20
#define NUM_PRODUCERS 4
#define NUM_CONSUMERS 3

int buffer[BUFFER_SIZE];
int in = 0;
int out = 0;
int produced_count = 0;
int consumed_count = 0;

// Variáveis para o Algoritmo de Lamport
volatile int choosing[NUM_PRODUCERS + NUM_CONSUMERS] = {0};
volatile int number[NUM_PRODUCERS + NUM_CONSUMERS] = {0};

sem_t full;
sem_t empty;

void lock(int thread_id) {
    choosing[thread_id] = 1;
    int max_number = 0;
    for (int i = 0; i < NUM_PRODUCERS + NUM_CONSUMERS; i++) {
        int num = number[i];
        max_number = num > max_number ? num : max_number;
    }
    number[thread_id] = max_number + 1;
    choosing[thread_id] = 0;

    for (int j = 0; j < NUM_PRODUCERS + NUM_CONSUMERS; j++) {
        while (choosing[j]) { /* Espera ativa */ }

        while (number[j] != 0 && (number[j] < number[thread_id] || (number[j] == number[thread_id] && j < thread_id))) {
            /* Espera ativa */
        }
    }
}

void unlock(int thread_id) {
    number[thread_id] = 0;
}

void* producer(void* arg) {
    int thread_id = *(int*)arg;
    int item = 1;

    while (1) {
        sem_wait(&empty);

        lock(thread_id);

        if (produced_count >= MAX_ITEMS) {
            unlock(thread_id);
            sem_post(&full); // consumidores não ficam bloqueados para sempre
            break;
        }

        buffer[in] = item;
        printf("Producer %d produced: %d\n", thread_id, item);
        item++;
        in = (in + 1) % BUFFER_SIZE;
        produced_count++;

        unlock(thread_id);

        sem_post(&full);
    }

    pthread_exit(NULL);
}

void* consumer(void* arg) {
    int thread_id = *(int*)arg;

    while (1) {
        sem_wait(&full);

        lock(thread_id + NUM_PRODUCERS);

        if (consumed_count >= MAX_ITEMS) {
            unlock(thread_id + NUM_PRODUCERS);
            sem_post(&empty); // produtores não ficam bloqueados para sempre
            break;
        }

        int item = buffer[out];
        printf("Consumer %d consumed: %d\n", thread_id, item);
        out = (out + 1) % BUFFER_SIZE;
        consumed_count++;

        unlock(thread_id + NUM_PRODUCERS);

        sem_post(&empty);
    }

    pthread_exit(NULL);
}

int main() {
    pthread_t producers[NUM_PRODUCERS], consumers[NUM_CONSUMERS];
    int producer_ids[NUM_PRODUCERS], consumer_ids[NUM_CONSUMERS];

    sem_init(&full, 0, 0);
    sem_init(&empty, 0, BUFFER_SIZE);

    for (int i = 0; i < NUM_PRODUCERS; i++) {
        producer_ids[i] = i;
        pthread_create(&producers[i], NULL, producer, (void*)&producer_ids[i]);
    }

    for (int i = 0; i < NUM_CONSUMERS; i++) {
        consumer_ids[i] = i;
        pthread_create(&consumers[i], NULL, consumer, (void*)&consumer_ids[i]);
    }

    for (int i = 0; i < NUM_PRODUCERS; i++) {
        pthread_join(producers[i], NULL);
    }

    for (int i = 0; i < NUM_CONSUMERS; i++) {
        pthread_join(consumers[i], NULL);
    }

    sem_destroy(&full);
    sem_destroy(&empty);

    return 0;
}
