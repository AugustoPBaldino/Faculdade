/*
  Pegando como base o código de "Acesso concorrente usando semafores" e juntando com a lógica 
    do problema dos leitores e escritores

  //https://moodle.pucrs.br/pluginfile.php/4881591/mod_resource/content/1/ex2_sem.c

  "exemplo com semaforos, com no maximo 3 threads estao acessando o recurso ao mesmo tempo"
*/

#include <stdio.h>
#include <pthread.h> 
#include <unistd.h>
#include <semaphore.h>
#include <stdlib.h>//permite o atoi
#include<stdbool.h>//permite a utilização do bool

#define MAX_RESOURCES 200
#define MAX_READERS 70

sem_t sem_canibal, sem_cozinheiro;// Declaração do semaforo para canibais e para o cozinheiro
//Primeiramente tentaremos, representando os pratos como int, posteriormente tentaremos representar os pratos como booleano em uma lista
long int max_r, r = 0, canibais; // "Maximo de porcoes", "Porcoes disponiveis", "Numero de canibais" (Threads) 
bool control_alim = false; //true == cozinheiro a cozinhar/canibais a esperar, 
                           //false == cozinheiro a dormir/canibais podem comer



struct Queue {//denomina a criação de uma lista
    long int travessa[MAX_READERS];
    long int inicio; // Indicador do início da fila 
    long int final;  // Indicador do final da fila
};

// Função para inicializar a fila
void initializeQueue(struct Queue *q) {
    q->inicio = 0;
    q->final = max_r;
    for(long int i = 0; i < max_r; i++){//inicia com todas as travessas cheias
      q->travessa[i] = 1;
    }
}



//------------------------------------------------------
// Definição das funções do Canibais e do Cozinheiro

void *mesa(void *arg)
{

  struct Queue *q = (struct Queue *)arg;
  long int inicio = q->inicio;
  long int final = q->final;

  while (1) {
    usleep(100000);
    inicio = q->inicio;
    if(inicio < final && control_alim == false)//dupla confirmação, para funcionar somente quando tiver recursos e quando o cozinheiro permitir
    {
      sem_wait(&sem_canibal);//Entra na sessão critica
      long int prato = q->inicio;//pega o valor do atual inicio
      if(q->travessa[prato] == 1){//verifica se o prato está vazio
        q->travessa[prato] = 0; // indica que o prato foi coletado
        q->inicio = q->inicio +1;//incrementa

        printf("Porcao %ld foi comida\n", prato);

        //cooldown para o canibal se alimentar
        usleep(100000 * canibais);
        if(prato == final-1){//Quando não há mais porcao com comida, o ultimo canibal acorda o cozinheiro
          printf("Canibal foi acordar o cozinheiro\n");
          control_alim = true;
        }

      }
      sem_post(&sem_canibal);
      //inicio--;//já informa que retirou um dos recursos
    }

    usleep(100000);
  }
}

//------------------------------------------------------
void *cozinha(void *arg)
{
  struct Queue *q = (struct Queue *)arg;// Cria um ponteiro, que é referente a lista de travessa
  long int inicio = q->inicio;
  long int final = q->final;
  while(1) {
    
    while(control_alim == false){//Enquanto houver porcoes disponiveis, o cozinheiro está dormindo
      inicio = q->inicio;
      usleep(100000);//Cozinheiro está a dormir
    }


    //acorda o cozinheiro
    sem_wait(&sem_cozinheiro);//Entra na sessão critica
    printf("O cozinheiro acordou\n");
    //-----------------------------------
    //nova maneira de encher a travessa
    q->inicio = 0; //reinicia o valor de inicio

    for(long int i = 0; i < max_r; i++){//enche a travessa
      q->travessa[i] = 1;
      usleep(100000);
    }
    printf("Cozinheiro encheu a travessa\n");


    sem_post(&sem_cozinheiro); //Sai da sessão critica
    printf(" Cozinheiro voltou a dormir\n\n");
    control_alim = false;
  }
}

//------------------------------------------------------
// main fuctions

int main(int argc, char *argv[]) {
  //Registra os valore de porções e canibais
  if (argc < 3) {
    printf("Uso: %s <num_porcoes> <num_canibais> \n", argv[0]);
    return 1;
  }

    max_r = atoi(argv[1]);
  printf("Numero de porcoes: %ld\n", max_r);
  int canibais = atoi(argv[2]);

  if (max_r > MAX_RESOURCES || canibais > MAX_READERS) {
    printf("Número máximo de porcoes ou canibais excedido.\n");
    return 1;
  }

  //------------------------------------------------------
  //Incia a lista de porções
  struct Queue travessa;
  initializeQueue(&travessa);
  printf("travessa criada e esta cheia\n");

  //struct ArgsMesa args[canibais];//permite a enumeração do canibale e ponteiro para a travessa

  pthread_t threads[canibais + 1];// +1 == cozinheiro

  //Denomina quantas threads terão acesso ao mesmo tempo
  sem_init(&sem_cozinheiro, 0, 1);
  sem_init(&sem_canibal, 0, canibais);


  // Cria a thread Cozinheiro
  pthread_create(&threads[canibais], NULL, cozinha, (void *)&travessa);

  //Cria as threads dos canibais
  for(long int i = 0; i < canibais; i++){
      //args[i].index = i;
      //args[i].q = &travessa;
      pthread_create(&threads[i], NULL, mesa, (void *)&travessa);
  }

  printf("\n");

  pthread_exit(NULL);

  return(0);
}