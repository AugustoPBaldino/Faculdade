# T1_Alest_2
Trabalho 1 da cadeira algoritmos e estruturas de dados 2.

O DNA D/N/A Depois de analisar uidadosamente o dis o voador que aiu no meio do parque da Redenção, os ientistas hegaram a algumas on lusões sobre os seres que o o upavam (e que fugiram em uma ápsula de resgate).
 
 Os cientistas des obriram que o DNA dos alienígenas é feito om 3 bases em vez das 4 bases do DNA terrestre. Ironi amente eles batizaram as 3 bases de D, N e A. Eles também des obriram que o DNA alienígena sofre mutações que o deterioram om o tempo: duas bases diferentes que estão uma ao lado da outra podem se fundir produzindo a ter eira base e riando uma adeia de DNA um pou o menor. Isto a onte e de uma forma muito organizada: 
 
 Em uma adeia de DNA a fusão de bases a onte e sempre na dupla de bases diferentes mais à esquerda; 
 
 A nova base riada om a fusão vai ser agregada ao final da adeia de DNA. Por exemplo, a pequena adeia DNA sofre uma deterioração em DN e a aba gerando AA. Já uma adeia maior omo DNANDANDANDANADNDDDAN acaba virando simplesmente N. 
 
 Os cientistas agora perguntam: dada uma adeia de DNA, qual o tamanho e qual adeia podem ser obtidos depois de todas as mutações possíveis?
 
Você deve escrever um algoritmo capaz de ler as cadeias que os cientistas colocaram em vários arquivos de teste e depois informe o tamanho da menor adeia que pode ser obtida em cada caso. Ao final vo ê deve apresentar um relatório descrevendo: 

Qual o problema sendo resolvido; 
Como o problema foi modelado;
Como é o processo de solução, apresentando exemplos e algoritmos; 
Os resultados dos asos de teste; 
Conclusões. 1