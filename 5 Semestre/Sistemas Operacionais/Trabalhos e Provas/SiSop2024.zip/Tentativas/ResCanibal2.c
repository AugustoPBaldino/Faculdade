/*
  Pegando como base o código de "Acesso concorrente usando semafores" e juntando com a lógica 
    do problema dos leitores e escritores

  //https://moodle.pucrs.br/pluginfile.php/4881591/mod_resource/content/1/ex2_sem.c

  "exemplo com semaforos, com no maximo 3 threads estao acessando o recurso ao mesmo tempo"
*/

#include <stdio.h>
#include <pthread.h> 
#include <unistd.h>
#include <semaphore.h>
#include <stdlib.h>//permite o atoi
#include<stdbool.h>//permite a utilização do bool

#define MAX_RESOURCES 1000
#define MAX_READERS 1000

sem_t sem_canibal, sem_mutex_r; // Declaração do semaforo para canibais, para o cozinheiro e o mutes4
long int max_r, r = 0, canibais; // "Maximo de porcoes", "Porcoes disponiveis", "Numero de canibais" (Threads) 
bool control_alim = false;  //true == cozinheiro a cozinhar/canibais a esperar, 
                            //false == cozinheiro a dormir/canibais podem comer

//------------------------------------------------------
// Definição das funções do Canibais e do Cozinheiro
void *mesa(void *arg)
{
    long int i;
    i = (long int)arg;
    while (1) {
        usleep(100000);
        if (control_alim == false) {
            sem_wait(&sem_canibal); //Entra na sessão critica
            sem_wait(&sem_mutex_r); // Espera pela exclusão mútua dos recursos
            if (r > 0) {
                long int prato = r--;
                sem_post(&sem_mutex_r); // Libera a exclusão mútua dos recursos
                printf(" Canibal %3ld pegou a porcao %3ld", i, prato);
                if (prato == 1) {//Quando não há mais porcao com comida, o ultimo canibal acorda o cozinheiro
                    printf("\n Canibal %3ld foi acordar o cozinheiro",i);
                    control_alim = true;
                }
                printf(" e foi embora\n");
                sem_post(&sem_canibal);
                usleep(1000000 * canibais);
            } else {//Canibal chegou na tevessa, mas não havia mais porções para pegar
                sem_post(&sem_mutex_r); // Libera a exclusão mútua dos recursos
                sem_post(&sem_canibal); //sai da sessão critica
            }
        }
    }
}


//------------------------------------------------------
// Definição das funções do Canibais e do Cozinheiro
void *cozinha(void *arg)
{
  while(1) {

    while(control_alim == false){//Enquanto houver porcoes disponiveis, o cozinheiro está dormindo
      usleep(100000);//Cozinheiro está a dormir
    }
    usleep(100000);
    //acorda o cozinheiro
    //sem_wait(&sem_cozinheiro);//Entra na sessão critica
    printf("\n O cozinheiro acordou\n");
    //-----------------------------------
    //enche a travessa
    r = max_r;
    usleep(100000);
    printf(" Cozinheiro encheu a travessa\n");


    //sem_post(&sem_cozinheiro); //Sai da sessão critica
    printf(" Cozinheiro voltou a dormir\n\n");
    control_alim = false;
  }
}

//------------------------------------------------------
// main fuctions

int main(int argc, char *argv[]) {
  //Registra os valore de porções e canibais
  if (argc < 3) {
    printf("Uso: %s <num_porcoes> <num_canibais> \n", argv[0]);
    return 1;
  }

    max_r = atoi(argv[1]);
  printf("Numero de porcoes: %ld\n", max_r);
  int canibais = atoi(argv[2]);

  if (max_r > MAX_RESOURCES || canibais > MAX_READERS) {
    printf("Número máximo de porcoes ou canibais excedido.\n");
    return 1;
  }

  //------------------------------------------------------
  pthread_t threads[canibais + 1];// +1 == cozinheiro

  //Denomina quantas threads terão acesso ao mesmo tempo
  //sem_init(&sem_cozinheiro, 0, 1);
  sem_init(&sem_canibal, 0, 1);
  sem_init(&sem_mutex_r, 0, 1); // Inicializa o semáforo para a exclusão mútua em r


  control_alim = true;
  // Cria a thread Cozinheiro
  pthread_create(&threads[canibais], NULL, cozinha, (void *)0);

  //Cria as threads dos canibais
  for(long int i = 0; i < canibais; i++){
      pthread_create(&threads[i], NULL, mesa, (void *)i);
  }

  printf("\n");

  pthread_exit(NULL);

  return(0);
}