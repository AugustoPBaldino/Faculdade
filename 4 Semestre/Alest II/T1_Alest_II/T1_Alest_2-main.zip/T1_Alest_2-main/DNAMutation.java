import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.util.HashMap;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;

public class DNAMutation {
    public static void main(String[] args) {
        String inputFileName = "Casos/caso7.txt";  // Nome do arquivo de entrada
        try {
            BufferedReader br = new BufferedReader(new FileReader(inputFileName));
            String dnaSequence;
            int caseNumber = 7;

            while ((dnaSequence = br.readLine()) != null) {
                Map<String, String> dnaSequences = new HashMap<>();
                dnaSequences.put("original", dnaSequence);

                // Processa as mutações e armazena a sequência final no HashMap
                processMutations(dnaSequences);

                // Imprime a sequência final
                System.out.println("Cadeia final no caso " + caseNumber + ": " + dnaSequences.get("final"));
                caseNumber++;

            }

            br.close();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    public static void processMutations(Map<String, String> dnaSequences) {
        String dna = dnaSequences.get("original");
        boolean mutated=true;

        
            mutated = false;
            List<Character> newDNA = new LinkedList<>();

            for (int i = 0; i < dna.length(); i++) {
                char nucleotide = dna.charAt(i);
                newDNA.add(nucleotide);
            }

    
            for (int i = 0; i < newDNA .size();i++) {
                char current = newDNA.get(i);
                char next = (i < newDNA .size() - 1) ? newDNA .get(i + 1) : '\0';

                if ((current == 'D' && next == 'N') || (current == 'N' && next == 'D')) {
                    newDNA.set(i, 'A');
                    newDNA.remove(i+1);
                    if(i==0)i= i-1;
                    if(i>=1)i= i-2;
                    mutated = true;
                } else if ((current == 'A' && next == 'N') || (current == 'N' && next == 'A')) {
                    newDNA.set(i, 'D');
                    newDNA.remove(i+1);
                    
                    if(i==0)i= i-1;
                    if(i>=1)i= i-2;
                    mutated = true;
                } else if ((current == 'A' && next == 'D') || (current == 'D' && next == 'A')) {
                    newDNA.set(i, 'N');
                    newDNA.remove(i+1);
                    
                    if(i==0)i= i-1;
                    if(i>=1)i= i-2;
                    mutated = true;
                } else if (i < newDNA.size() - 2 && current == next && next == newDNA.get(i + 2)) {
                    mutated = true;
                }else{
                    mutated=false;
                }
            
            }

            // Atualiza a sequência final
            StringBuilder result = new StringBuilder(newDNA.size());
            for (Character c : newDNA) {
                result.append(c);
            }
            dna = result.toString();
        

        // Atualiza a sequência final no HashMap
        dnaSequences.put("final", dna);
    }
}
