#include <stdio.h>
#include <stdlib.h>
#include <pthread.h>
#include <semaphore.h>

#define MAX 10 // Tamanho da fila

int fila[MAX];
int inicio = 0;
int fim = -1;
int contador = 0;

sem_t mutex;
sem_t espacosVazios;
sem_t espacosPreenchidos;

void inserir(int item) {
    fim = (fim + 1) % MAX;
    fila[fim] = item;
    contador++;
}

int remover() {
    int item = fila[inicio];
    inicio = (inicio + 1) % MAX;
    contador--;
    return item;
}

void* produtor(void* param) {
    for (int i = 0; i < 20; i++) {
        sem_wait(&espacosVazios);
        sem_wait(&mutex);
        inserir(i);
        printf("Produtor produziu %d\n", i);
        sem_post(&mutex);
        sem_post(&espacosPreenchidos);
    }
}

void* consumidor(void* param) {
    for (int i = 0; i < 20; i++) {
        sem_wait(&espacosPreenchidos);
        sem_wait(&mutex);
        int item = remover();
        printf("Consumidor consumiu %d\n", item);
        sem_post(&mutex);
        sem_post(&espacosVazios);
    }
}

int main() {
    pthread_t idProdutor, idConsumidor;

    sem_init(&mutex, 0, 1);
    sem_init(&espacosVazios, 0, MAX);
    sem_init(&espacosPreenchidos, 0, 0);

    pthread_create(&idProdutor, NULL, produtor, NULL);
    pthread_create(&idConsumidor, NULL, consumidor, NULL);

    pthread_join(idProdutor, NULL);
    pthread_join(idConsumidor, NULL);

    return 0;
}