#include <stdio.h>
#include <pthread.h>
#include <unistd.h>
#include <semaphore.h>
#include <stdlib.h>

#define MAX_RESOURCES 100
#define MAX_READERS 100

sem_t mutex;
sem_t read_sem[MAX_RESOURCES];
int resources[MAX_RESOURCES];
int num_resources;
int resources_available;

//Lista de recursos booleano onde 1 porcao cheia e 0 porcao vazia
//nao deve escolher recursos aleatórios.


void *reader(void *arg) {
    int tid = (int)(long int)arg;
    while (1) {
        sem_wait(&read_sem[tid]); // Bloqueia o acesso de leitura para este leitor
        if (resources_available <= 0) {
            printf( "Leitor %d: Não há recursos disponíveis para leitura.\n", tid);
          
            sem_post(&read_sem[tid]); // Libera o acesso de leitura para este leitor
            break; // Sai do loop se não houver mais recursos
        }
        int index = (int)(rand() % num_resources); // Escolhe um porcao aleatório
        printf("Canibal %d está comendo a porcao %d (%d)\n", tid, index, resources[index]);
        usleep(100000); // Simula a leitura
        usleep(100000 * num_resources);
    }
    printf("Leitor %d terminou de ler todos os recursos\n", tid);
    pthread_exit(NULL);
}
/*
void *writer(void *arg) {//Cozinheiro
    while (1) {
        //Enquanto ainda tiver recurss
        while(resources_available > 0){
          sem_wait(&mutex); // Cozinheiro está a dormir
        }
        sem_post(&mutex); // Acorda o Cozinheiro
        printf("Cozinheiro está a encher a travessa\n");
        //reestabelece todos os recursos
        resources_available = num_resources;
        usleep(100000);
        printf("\n\n Uma nova travessa de %d porcoes foi feita\n\n", num_resources);
    }
    pthread_exit(NULL);
}
*/

void *writer(void *arg) {
    while (1) {
        sem_wait(&mutex); // Bloqueia o acesso ao recurso compartilhado
        if (resources_available == 0) {
            // Se não houver recursos disponíveis, o cozinheiro reabastece as travessas
            printf("Cozinheiro está a encher a travessa\n");
            resources_available = num_resources;
            printf("\n\n Uma nova travessa de %d porções foi feita\n\n", num_resources);
        }
        sem_post(&mutex); // Libera o acesso ao recurso compartilhado
        usleep(100000); // Tempo de espera antes de verificar novamente
    }
    pthread_exit(NULL);
}



int main(int argc, char *argv[]) {
    if (argc < 3) {
        printf("Uso: %s <num_recursos> <num_leitores>\n", argv[0]);
        return 1;
    }

    num_resources = atoi(argv[1]);
    printf("Numero de recursos: %d\n", num_resources);
    int num_readers = atoi(argv[2]);

    if (num_resources > MAX_RESOURCES || num_readers > MAX_READERS) {
        printf("Número máximo de recursos ou leitores excedido.\n");
        return 1;
    }

    //Começa com todos os pratos vazios
    resources_available = 0;

    sem_init(&mutex, 0, 1); // Inicializa o semáforo de escrita com 1
    for (int i = 0; i < num_resources; i++) {
        sem_init(&read_sem[i], 0, num_readers);
        resources[i] = 0;
    }

    pthread_t threads[num_readers + 1]; // +1 para o escritor

    // Cria a thread Cozinheiro
    pthread_create(&threads[num_readers], NULL, writer, NULL);
  
    // Cria threads Canibais
    for (long int i = 0; i < num_readers; i++) {
        pthread_create(&threads[i], NULL, reader, (void *)i);
    }

    // Aguarda as threads terminarem
    for (int i = 0; i < num_readers + 1; i++) {
        printf("join threads %d",i);
        pthread_join(threads[i], NULL);
    }

    return 0;
}
