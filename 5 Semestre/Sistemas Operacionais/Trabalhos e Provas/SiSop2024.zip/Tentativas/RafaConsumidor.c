#include <stdio.h>
#include <pthread.h>
#include <unistd.h>
#include <semaphore.h>
#include <stdlib.h>

#define BUFFER_SIZE 5
#define MAX_ITEMS 20

int buffer[BUFFER_SIZE];
int in = 0; // Índice de inserção no buffer
int out = 0; // Índice de remoção do buffer
int count = 0; // Contador de itens no buffer
int turn = 0; // Variável de turno para priorização

sem_t mutex;
sem_t full;
sem_t empty;

void* producer(void* arg) {
    while (1) {
        usleep(1000);
        sem_wait(&empty); // Espera o buffer não estar cheio
        sem_wait(&mutex); // Bloqueia o acesso ao buffer

        int item = count; // Pega um item
        buffer[in] = count; // Coloca o item no buffer
        printf("Produced e ficou %d\n", item + 1);
        in = (in + 1) % BUFFER_SIZE; // Atualiza o índice de inserção
        if(count < MAX_ITEMS){count++;} // Incrementa o contador de itens no buffer

        sem_post(&mutex); // Libera o acesso ao buffer
        sem_post(&full); // Sinaliza que há um item para consumir
    }
}

void* consumer(void* arg) {
    while (1) {
        usleep(1000);
        sem_wait(&full); // Espera o buffer não estar vazio
        sem_wait(&mutex); // Bloqueia o acesso ao buffer
        
        int item = buffer[out]; // Remove um item do buffer
        printf("Consumed: %d\n", item+1);
        out = (out + 1) % BUFFER_SIZE; // Atualiza o índice de remoção
        count--; // Decrementa o contador de itens no buffer

        sem_post(&mutex); // Libera o acesso ao buffer
        sem_post(&empty); // Sinaliza que há espaço para produzir
    }
}

int main() {
    pthread_t producerThread, consumerThread;

    sem_init(&mutex, 0, 1); // Inicializa o semáforo de exclusão mútua
    sem_init(&full, 0, 0); // Inicializa o semáforo de itens no buffer
    sem_init(&empty, 0, BUFFER_SIZE); // Inicializa o semáforo de espaços vazios no buffer

    pthread_create(&producerThread, NULL, producer, NULL); // Cria a thread produtora
    pthread_create(&consumerThread, NULL, consumer, NULL); // Cria a thread consumidora

    pthread_join(producerThread, NULL); // Espera a thread produtora terminar
    pthread_join(consumerThread, NULL); // Espera a thread consumidora terminar

    sem_destroy(&mutex); // Destrói o semáforo de exclusão mútua
    sem_destroy(&full); // Destrói o semáforo de itens no buffer
    sem_destroy(&empty); // Destrói o semáforo de espaços vazios no buffer

    return 0;
}
