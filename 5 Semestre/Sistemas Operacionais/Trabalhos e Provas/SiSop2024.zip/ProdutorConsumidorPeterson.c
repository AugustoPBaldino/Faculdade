#include <stdio.h>
#include <stdlib.h>
#include <pthread.h>
#include <semaphore.h>
#include <stdbool.h>

#define MAX 10 // Tamanho da fila
#define PRODUTORES 5 // Número de produtores
#define CONSUMIDORES 5 // Número de consumidores

int fila[MAX];
int inicio = 0;
int fim = -1;
int contador = 0;

bool flag[2];
int turn;

sem_t espacosVazios;
sem_t espacosPreenchidos;

void lock(int self) {
    flag[self] = true;
    turn = 1 - self;
    while (flag[1 - self] && turn == 1 - self);
}

void unlock(int self) {
    flag[self] = false;
}

void inserir(int item) {
    fim = (fim + 1) % MAX;
    fila[fim] = item;
    contador++;
}

int remover() {
    int item = fila[inicio];
    inicio = (inicio + 1) % MAX;
    contador--;
    return item;
}

void imprimirFila() {
    printf("Tamanho da fila: %d\n", contador);
    printf("Itens na fila: ");
    for (int i = 0; i < contador; i++) {
        printf("%d ", fila[(inicio + i) % MAX]);
    }
    printf("\n");
}

void* produtor(void* param) {
    int id = *(int*)param;
    for (int i = 0; true; i++) {
        sem_wait(&espacosVazios);
        printf("Produtor %d pronto para produzir\n", id);
        lock(id);
        printf("Produtor %d na fila da seção crítica\n", id);
        inserir(i);
        printf("Produtor %d produziu %d\n\n", id, i);
        imprimirFila();
        unlock(id);
        sem_post(&espacosPreenchidos);
    }
}

void* consumidor(void* param) {
    int id = *(int*)param;
    for (int i = 0; true; i++) {
        sem_wait(&espacosPreenchidos);
        printf("Consumidor %d pronto para consumir\n", id);
        lock(id);
        printf("Consumidor %d na fila da seção crítica\n", id);
        int item = remover();
        printf("Consumidor %d consumiu %d\n\n", id, item);
        imprimirFila();
        unlock(id);
        sem_post(&espacosVazios);
    }
}

int main() {
    pthread_t idProdutor[PRODUTORES], idConsumidor[CONSUMIDORES];
    int ids[PRODUTORES + CONSUMIDORES];

    flag[0] = flag[1] = false;
    turn = 0;

    sem_init(&espacosVazios, 0, MAX);
    sem_init(&espacosPreenchidos, 0, 0);

    for (int i = 0; i < PRODUTORES; i++) {
        ids[i] = i;
        pthread_create(&idProdutor[i], NULL, produtor, &ids[i]);
    }

    for (int i = 0; i < CONSUMIDORES; i++) {
        ids[i] = i;
        pthread_create(&idConsumidor[i], NULL, consumidor, &ids[i]);
    }

    for (int i = 0; i < PRODUTORES; i++) {
        pthread_join(idProdutor[i], NULL);
    }

    for (int i = 0; i < CONSUMIDORES; i++) {
        pthread_join(idConsumidor[i], NULL);
    }

    return 0;
}
